XFORMAL: A Benchmark for Multilingual Formality Style Transfer


1. INTRODUCTION

This repository contains code and data from the NAACL 2021 paper entitled "XFORMAL: A Benchmark for Multilingual Formality Style Transfer".  The paper can be found in the "papers" subdirectory as well as on the web:

https://aclanthology.org/2021.naacl-main.256.pdf
https://arxiv.org/pdf/2104.04108.pdf

If you use any of the contents of this repository, please cite the paper:

@inproceedings{briakou-etal-2021-ola,
    title = "Ol{\'a}, Bonjour, Salve! {XFORMAL}: A Benchmark for Multilingual Formality Style Transfer",
    author = "Briakou, Eleftheria  and
      Lu, Di  and
      Zhang, Ke  and
      Tetreault, Joel",
    booktitle = "Proceedings of the 2021 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies",
    month = jun,
    year = "2021",
    address = "Online",
    publisher = "Association for Computational Linguistics",
    url = "https://www.aclweb.org/anthology/2021.naacl-main.256",
    pages = "3199--3216",
    abstract = "We take the first step towards multilingual style transfer by creating and releasing XFORMAL, a benchmark of multiple formal reformulations of informal text in Brazilian Portuguese, French, and Italian. Results on XFORMAL suggest that state-of-the-art style transfer approaches perform close to simple baselines, indicating that style transfer is even more challenging when moving multilingual.",
}

The above bib entry is from the ACL Anthology: https://aclanthology.org/2021.naacl-main.256.bib




2. USAGE GUIDANCE

Note that to use this corpus, you must have been granted permission access from Yahoo Webscope to the underlying L6 - Yahoo! Answers Comprehensive Questions and Answers version 1.0: 

https://webscope.sandbox.yahoo.com/catalog.php?datatype=l 

This Yahoo Answers corpus can be requested free of charge for **research purposes**.   XFORMAL also abides by the same terms of use as L6.





3. CONTACT

For any questions, please contact Eleftheria Briakou (ebriakou@cs.umd.edu) and Joel Tetreault (tetreaul@gmail.com).



4. TABLE OF CONTENTS

* gyafc_translated: the GYAFC translated into Brazilian Portuguese, Italian, and French.  Note that in the test subdirectories, "informal.ref0" refers to one set of informal rewrites of "formal".  Conversely, "formal.ref3" refers to one set of formal rewrites of "informal".

* mturk: Amazon Mechanical Turk templates, qualification tests, and annotations results.

* papers: the XFORMAL and GYAFC papers downloaded from arxiv on May 29.

* rule_based: scripts for replicating rule based formality style transfer in the three languages of XFORMAL.

* xformal_eval: dataset consisting of informal sentences with multiple human generated formality rewrites in Brazilian Portuguese, Italian, and French.


5. GYAFC

This corpus leverages the GYAFC which is the original dataset of formal-informal rewrites for English Yahoo Answers sentences.  We recommend gaining access 



