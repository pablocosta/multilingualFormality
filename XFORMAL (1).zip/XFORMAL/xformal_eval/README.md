<p align="center">
    <img align="left" src="static/logo.png", width="200" />
</p>

---

This repository contains XFORMAL,  an evaluation dataset, that consists of multiple formal  rewrites  of  informal  sentences  in  three  Romance languages:  Brazilian Portuguese (BR-PT),French (FR), and Italian (IT).

## Example rewrites

<p align="center">
   <img src="static/xformal_samples.png", width="1000" />
</p>

## Contact

If you use any contents of this repository, please cite us. For any questions, write to ebriakou@cs.umd.edu.

```
@inproceedings{briakou-etal-2021-xformal,
    title = "XFORMAL: A Benchmark for Multilingual Formality Style Transfer",
    author = "Briakou, Eleftheria and Lu, Di and Zhang, Ke and Tetreault, Joel",
    booktitle = "Proceedings of the 2021 Annual Conference of the North American Chapter of the Association for Computational Linguistics (NAACL)",
    year = "2021",
    address = "Online",
    publisher = "Association for Computational Linguistics"
}
```
